"""FastAPI adapter to the same application service (optional deployment)."""
from fastapi import FastAPI,Request
from fastapi.responses import Response,JSONResponse
from fastapi.staticfiles import StaticFiles
from .service import dispatch,ROOT
from .storage import Conflict
app=FastAPI(title='СтройОбъём',version='0.1.0')
@app.api_route('/api/{route:path}',methods=['GET','POST','PUT'])
async def api(route:str,request:Request):
    try:
        chunks=[]; total=0
        async for chunk in request.stream():
            total+=len(chunk)
            if total>41*1024*1024: return JSONResponse({'error':'Слишком большой запрос'},413)
            chunks.append(chunk)
        status,data=dispatch(request.method,'/api/'+route,b''.join(chunks),dict(request.headers))
        if isinstance(data,bytes): return Response(data,status,media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',headers={'Content-Disposition':'attachment; filename="stroyobem.xlsx"'})
        return JSONResponse(data,status)
    except Conflict as e: return JSONResponse({'error':str(e)},409)
    except KeyError as e: return JSONResponse({'error':str(e)},404)
    except (ValueError,TypeError) as e: return JSONResponse({'error':str(e)},400)
app.mount('/',StaticFiles(directory=ROOT/'web',html=True),name='ui')
