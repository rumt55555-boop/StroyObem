"""Local single-user server. Bind to loopback by default, never public hosting."""
import json,mimetypes,argparse
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from urllib.parse import urlsplit
from .service import dispatch,ROOT
from .storage import Conflict
class Handler(BaseHTTPRequestHandler):
    def do_GET(self): self.handle_request()
    def do_POST(self): self.handle_request()
    def do_PUT(self): self.handle_request()
    def log_message(self,*args): pass
    def handle_request(self):
        path=urlsplit(self.path).path
        try:
            if path.startswith('/api/'):
                n=int(self.headers.get('Content-Length',0))
                if n>41*1024*1024: self.respond(413,{'error':'Превышен размер запроса'}); return
                status,data=dispatch(self.command,path,self.rfile.read(n),{k.lower():v for k,v in self.headers.items()})
                self.respond(status,data,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' if isinstance(data,bytes) else None)
            else:
                name={'/':'index.html','/app.js':'app.js','/style.css':'style.css','/sw.js':'sw.js'}.get(path)
                if not name: raise KeyError('Не найдено')
                f=ROOT/'web'/name; self.respond(200,f.read_bytes(),mimetypes.guess_type(name)[0])
        except Conflict as e: self.respond(409,{'error':str(e)})
        except KeyError as e: self.respond(404,{'error':str(e)})
        except (ValueError,TypeError) as e: self.respond(400,{'error':str(e)})
        except Exception: self.respond(500,{'error':'Внутренняя ошибка сервера. Данные не подтверждены.'})
    def respond(self,status,data,mime=None):
        raw=data if isinstance(data,bytes) else json.dumps(data,ensure_ascii=False,allow_nan=False).encode()
        self.send_response(status); self.send_header('Content-Type',mime or 'application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(raw))); self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Cache-Control','no-store' if self.path.startswith('/api/') else 'no-cache')
        if isinstance(data,bytes) and mime and 'spreadsheet' in mime: self.send_header('Content-Disposition','attachment; filename="stroyobem.xlsx"')
        self.end_headers(); self.wfile.write(raw)
if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--host',default='127.0.0.1'); parser.add_argument('--port',type=int,default=8000); a=parser.parse_args()
    print(f'СтройОбъём: http://{a.host}:{a.port}',flush=True)
    ThreadingHTTPServer((a.host,a.port),Handler).serve_forever()
