from io import BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font,Alignment
from openpyxl.workbook.properties import CalcProperties
from .engine import evaluate,KINDS
HEADERS=['№','Код элемента','Раздел','Этаж / отметка','Оси','Наименование работы','Тип','Размеры','Количество','Формула','Подстановка','Объём','Ед.','Нормативный источник','Пункт','Чертёж','Статус','Примечания','L, м','H/h, м','t, м','S, м²','S проёмов, м²']
def safe(v):
    if isinstance(v,str) and v[:1] in ('=','+','-','@'): return "'"+v
    return v

def workbook(p,final=False):
    rows=evaluate(p)
    if final and (not rows or any(not r['confirmed'] for r in rows)): raise ValueError('Окончательная ведомость требует подтверждения всех включённых элементов')
    wb=Workbook(); wb.remove(wb.active); wb.calculation=CalcProperties(calcId=191029,fullCalcOnLoad=True)
    elements={e['id']:e for e in p['elements']}; pages={x['id']:x for x in p['pages']}
    for name in ['Общие работы','Монолитные работы','Земляные работы']:
        ws=wb.create_sheet(name); ws.append(HEADERS)
        for r in rows:
            e=elements[r['id']]; earth=e['kind']=='pit'
            if name=='Монолитные работы' and earth or name=='Земляные работы' and not earth: continue
            i=ws.max_row+1; d=r.get('inputs',{}); pg=pages.get(e['page'],{})
            formula=f'=(S{i}*T{i}-W{i})*U{i}' if e['kind']=='wall' else f'=(V{i}-W{i})*T{i}'
            status='Подтверждено' if r['confirmed'] else 'Требует проверки'
            values=[i-1,e['id'],e.get('section','КР'),e.get('floor',''),e.get('axes',''),'Разработка грунта (естественное залегание)' if earth else 'Бетонирование',KINDS[e['kind']],str(d),1,r.get('formula',''),r.get('substitution',''),formula if not r['errors'] else None,'м³','Не назначен — геометрический подсчёт','',f"{pg.get('name','')} / лист {pg.get('number','')}",status,'; '.join(r['errors'])+' '+e.get('notes',''),d.get('length'),d.get('height'),d.get('thickness'),d.get('area'),d.get('openings')]
            ws.append([safe(v) if j!=11 else v for j,v in enumerate(values)])
        last=ws.max_row
        # Separate operations even when units match; no concrete+soil grand total.
        for operation in ['Бетонирование','Разработка грунта (естественное залегание)']:
            i=ws.max_row+1; ws.cell(i,6,'Итого: '+operation)
            ws.cell(i,12,f'=SUMIF(F2:F{last},"{operation}",L2:L{last})' if last>=2 else '=0')
            ws.cell(i,13,'м³')
        ws.freeze_panes='C2'; ws.auto_filter.ref=f'A1:W{last}'
        for col in ws.columns:
            ws.column_dimensions[col[0].column_letter].width=24
            for c in col:
                c.font=Font(name='Times New Roman',size=11,bold=c.row==1,color='000000')
                c.alignment=Alignment(vertical='top',wrap_text=True)
        ws.column_dimensions['L'].width=18
    ws=wb.create_sheet('Настройки проекта')
    for row in [('Проект',p['name']),('Режим','Геометрический'),('Версия проекта',p['revision']),('Ведомость','Окончательная' if final else 'ЧЕРНОВИК'),('Единицы','метры, м², м³'),('Котлован','Вертикальные стенки; без откосов'),('Нормативы','Не применены'),('Округление','Полная точность в формулах; формат 0.000')]: ws.append([safe(v) for v in row])
    for pg in p['pages']: ws.append([safe(pg['id']),safe(str(pg.get('calibration',{})))])
    for sheet in wb:
        for row in sheet:
            for c in row:
                if c.data_type=='f': c.number_format='0.000'
    bio=BytesIO(); wb.save(bio); return bio.getvalue()
