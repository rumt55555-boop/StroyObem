import base64,copy,json,os,re,uuid
from pathlib import Path
import fitz
from .engine import evaluate
from .storage import Store,Conflict
from .export import workbook
ROOT=Path(__file__).resolve().parent.parent
DATA=Path(os.environ.get('STROY_DATA',ROOT/'data')); DATA.mkdir(parents=True,exist_ok=True)
store=Store(DATA/'projects.sqlite3')

def valid_id(s):
    if not re.fullmatch(r'[a-zA-Z0-9_-]{1,80}',s): raise ValueError('Недопустимый идентификатор')

def validate(p):
    if not isinstance(p.get('name'),str) or not p['name'].strip() or len(p['name'])>200: raise ValueError('Введите название проекта (до 200 символов)')
    for key in ['pages','elements']:
        if not isinstance(p.get(key),list) or len(p[key])>2000: raise ValueError('Слишком большой проект')
        ids=[x['id'] for x in p[key]]
        for i in ids: valid_id(i)
        if len(set(ids))!=len(ids): raise ValueError('Повторяющийся идентификатор')
    for page in p['pages']:
        for k in ['width','height']:
            if not isinstance(page[k],(int,float)) or not 0<page[k]<20000: raise ValueError('Недопустимый размер страницы')
    for e in p['elements']:
        if len(json.dumps(e))>100000: raise ValueError('Слишком большой элемент')

def save_project(pid,p):
    old=store.get(pid); validate(p)
    p['id']=pid
    # Server owns immutable PDF metadata. Calibration is editable.
    oldpages={x['id']:x for x in old['pages']}
    for pg in p['pages']:
        if pg['id'] not in oldpages: raise ValueError('Лист не принадлежит проекту')
        for field in ('width','height','name','number','document'):
            pg[field]=oldpages[pg['id']][field]
    oldelements={x['id']:x for x in old['elements']}
    for e in p['elements']:
        before=copy.deepcopy(oldelements.get(e['id'],{})); after=copy.deepcopy(e)
        before.pop('confirmed',None); after.pop('confirmed',None)
        samepage=oldpages.get(e['page'],{}).get('calibration')==next((pg.get('calibration') for pg in p['pages'] if pg['id']==e['page']),None)
        e['confirmed']=bool(oldelements.get(e['id'],{}).get('confirmed')) and before==after and samepage
    return store.save(p,p['revision'])

def dispatch(method,path,body,headers):
    bits=path.strip('/').split('/')
    if path=='/api/projects' and method=='GET': return 200,store.list()
    if path=='/api/projects' and method=='POST':
        p=json.loads(body); p={'id':uuid.uuid4().hex,'name':p.get('name',''),'revision':0,'pages':[],'elements':[]}; validate(p)
        return 201,store.save(p,0)
    if len(bits)<3 or bits[:2]!=['api','projects']: raise KeyError('Маршрут не найден')
    pid=bits[2]; valid_id(pid); p=store.get(pid)
    if len(bits)==3:
        if method=='GET': return 200,p
        if method=='PUT': return 200,save_project(pid,json.loads(body))
    action=bits[3] if len(bits)>3 else ''
    if action=='history' and method=='GET': return 200,store.history(pid)
    if action=='calculate' and method=='GET': return 200,evaluate(p)
    if action=='confirm' and method=='POST':
        data=json.loads(body); target=data['id']; rows=evaluate(p)
        row=next((r for r in rows if r['id']==target),None)
        if not row or row['errors']: raise ValueError('Исправьте ошибки перед подтверждением')
        for e in p['elements']:
            if e['id']==target: e['confirmed']=True
        return 200,store.save(p,data['revision'])
    if action in ('export','final') and method=='GET': return 200,workbook(p,action=='final')
    if action=='pdf' and method=='POST':
        if len(body)>40*1024*1024: raise ValueError('Максимум 40 МБ')
        try: doc=fitz.open(stream=body,filetype='pdf')
        except Exception: raise ValueError('Не удалось прочитать PDF')
        if doc.needs_pass or not 0<len(doc)<=150: doc.close(); raise ValueError('Нужен PDF без пароля, до 150 листов')
        docid=uuid.uuid4().hex; filename=headers.get('x-filename','drawing.pdf')
        from urllib.parse import unquote
        filename=unquote(filename)[:200]
        pages=[]
        for i,page in enumerate(doc):
            if max(page.rect.width,page.rect.height)>5000: doc.close(); raise ValueError('Лист слишком большой')
            pages.append({'id':uuid.uuid4().hex,'document':docid,'name':filename,'number':i+1,'width':page.rect.width,'height':page.rect.height,'calibration':None})
        doc.close()
        (DATA/(docid+'.pdf')).write_bytes(body)
        p['pages'].extend(pages)
        for e in p['elements']: e['confirmed']=False
        return 200,store.save(p,p['revision'])
    if action=='page' and method=='GET' and len(bits)==5:
        page=next((x for x in p['pages'] if x['id']==bits[4]),None)
        if not page: raise KeyError('Лист не найден')
        with fitz.open(DATA/(page['document']+'.pdf')) as doc:
            pg=doc[page['number']-1]; factor=min(2,1800/max(pg.rect.width,pg.rect.height))
            pix=pg.get_pixmap(matrix=fitz.Matrix(factor,factor),alpha=False)
            return 200,{'image':'data:image/png;base64,'+base64.b64encode(pix.tobytes('png')).decode()}
    raise KeyError('Маршрут не найден')
