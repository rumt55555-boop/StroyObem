import json,sqlite3,uuid,datetime
from pathlib import Path
class Conflict(Exception): pass
class Store:
    def __init__(self,path):
        self.path=str(path)
        Path(path).parent.mkdir(parents=True,exist_ok=True)
        with self.connect() as c:
            c.executescript('CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY, revision INTEGER, body TEXT); CREATE TABLE IF NOT EXISTS history(project TEXT, revision INTEGER, at TEXT, body TEXT, PRIMARY KEY(project,revision));')
    def connect(self): return sqlite3.connect(self.path,timeout=15)
    def list(self):
        with self.connect() as c: return [json.loads(r[0]) for r in c.execute('SELECT body FROM projects ORDER BY rowid DESC')]
    def get(self,pid):
        with self.connect() as c: r=c.execute('SELECT body FROM projects WHERE id=?',(pid,)).fetchone()
        if not r: raise KeyError('Проект не найден')
        return json.loads(r[0])
    def save(self,p,expected):
        with self.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            row=c.execute('SELECT revision FROM projects WHERE id=?',(p['id'],)).fetchone()
            rev=row[0] if row else 0
            if expected!=rev: raise Conflict('Проект изменён на другом устройстве. Сохраните локальную копию и перезагрузите серверную версию.')
            p['revision']=rev+1
            p['updated']=datetime.datetime.now(datetime.timezone.utc).isoformat()
            body=json.dumps(p,ensure_ascii=False,allow_nan=False)
            c.execute('INSERT OR REPLACE INTO projects VALUES(?,?,?)',(p['id'],p['revision'],body))
            c.execute('INSERT INTO history VALUES(?,?,?,?)',(p['id'],p['revision'],p['updated'],body))
        return p
    def history(self,pid):
        with self.connect() as c: return [{'revision':r[0],'at':r[1]} for r in c.execute('SELECT revision,at FROM history WHERE project=? ORDER BY revision DESC',(pid,))]
