"""Deterministic geometry engine. Coordinates are PDF points; all results are SI."""
import math
from itertools import combinations

VERSION = '1.0.0'
KINDS = {'wall':'Стена','column':'Колонна','slab':'Плита','pit':'Котлован'}

def number(v, name, positive=True):
    if isinstance(v, bool) or not isinstance(v, (int,float)) or not math.isfinite(v):
        raise ValueError(f'{name}: требуется конечное число')
    if v <= 0 if positive else v < 0:
        raise ValueError(f'{name}: недопустимое значение')
    return float(v)

def points(raw):
    if not isinstance(raw,list) or len(raw)>1000:
        raise ValueError('Недопустимый контур')
    out=[]
    for p in raw:
        if not isinstance(p,list) or len(p)!=2: raise ValueError('Точка: нужны X и Y')
        out.append(tuple(number(x,'Координата',False) for x in p))
    return out

def cross(a,b,c): return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def on(a,b,p): return abs(cross(a,b,p))<1e-9 and min(a[0],b[0])-1e-9<=p[0]<=max(a[0],b[0])+1e-9 and min(a[1],b[1])-1e-9<=p[1]<=max(a[1],b[1])+1e-9

def intersects(a,b,c,d):
    x,y,z,w=cross(a,b,c),cross(a,b,d),cross(c,d,a),cross(c,d,b)
    return (x*y<0 and z*w<0) or on(a,b,c) or on(a,b,d) or on(c,d,a) or on(c,d,b)

def area(p):
    n=len(p)
    if n<3 or len(set(p))!=n: raise ValueError('Контур: нужны минимум 3 разные вершины')
    for i,j in combinations(range(n),2):
        if (i-j)%n in (1,n-1): continue
        if intersects(p[i],p[(i+1)%n],p[j],p[(j+1)%n]): raise ValueError('Самопересечение контура')
    a=abs(sum(p[i][0]*p[(i+1)%n][1]-p[(i+1)%n][0]*p[i][1] for i in range(n)))/2
    return number(a,'Площадь')

def scale(page):
    c=page.get('calibration') or {}
    if not c.get('verified'): raise ValueError('Масштаб страницы не проверен')
    p=points(c.get('points',[]))
    if len(p)!=2: raise ValueError('Для калибровки нужны 2 точки')
    distance=number(math.dist(*p),'База калибровки')
    return number(c.get('meters'),'Известное расстояние')/distance

def calculate(e,page):
    k=e.get('kind')
    if k not in KINDS: raise ValueError('Неизвестный тип конструкции')
    s=scale(page); p=points(e.get('points',[]))
    for x,y in p:
        if x>page['width'] or y>page['height']: raise ValueError('Контур вне страницы')
    h=number(e.get('height'),'Высота / толщина / глубина')
    opening=number(e.get('openings',0),'Проёмы, м²',False)
    if k=='wall':
        if len(p)!=2: raise ValueError('Стена задаётся двумя точками оси')
        length=number(math.dist(*p)*s,'Длина стены')
        t=number(e.get('thickness'),'Толщина стены')
        base=length*h
        if opening>=base: raise ValueError('Проёмы не могут быть больше или равны площади стены')
        v=(base-opening)*t
        formula='V = (L × H − Sпр) × t'
        substitution=f'({length:.6g} × {h:.6g} − {opening:.6g}) × {t:.6g}'
        inputs={'length':length,'height':h,'thickness':t,'openings':opening,'area':base}
    else:
        a=area(p)*s*s
        if k=='pit' and opening: raise ValueError('Проёмы котлована не поддерживаются')
        if opening>=a: raise ValueError('Отверстия не могут быть больше или равны площади контура')
        v=(a-opening)*h
        formula='V = (S − Sотв) × h'
        substitution=f'({a:.6g} − {opening:.6g}) × {h:.6g}'
        inputs={'area':a,'height':h,'openings':opening,'length':0,'thickness':0}
    return {'value':v,'unit':'м³','formula':formula,'substitution':substitution,'inputs':inputs,'scale':s,'engine':VERSION,'mode':'geometry'}

def evaluate(project):
    pages={p['id']:p for p in project.get('pages',[])}; results=[]
    for e in project.get('elements',[]):
        if e.get('excluded'): continue
        row={'id':e['id'],'errors':[],'confirmed':False}
        try:
            if e.get('page') not in pages: raise ValueError('Нет исходного листа')
            row.update(calculate(e,pages[e['page']]))
        except (ValueError,TypeError,KeyError) as ex: row['errors'].append(str(ex))
        results.append(row)
    # Conservative overlap guard: bounding boxes on the same drawing and floor.
    byid={e['id']:e for e in project.get('elements',[])}
    for a,b in combinations(results,2):
        if a['errors'] or b['errors']: continue
        ea,eb=byid[a['id']],byid[b['id']]
        if (ea['page'],ea.get('floor',''),ea['kind']=='pit')!=(eb['page'],eb.get('floor',''),eb['kind']=='pit'): continue
        def bounds(e,r):
            p=e['points']; pad=(e.get('thickness',0)/r['scale']/2) if e['kind']=='wall' else 0
            return min(x[0] for x in p)-pad,min(x[1] for x in p)-pad,max(x[0] for x in p)+pad,max(x[1] for x in p)+pad
        x,y=bounds(ea,a),bounds(eb,b)
        if min(x[2],y[2])-max(x[0],y[0])>1e-8 and min(x[3],y[3])-max(x[1],y[1])>1e-8:
            for row,other in ((a,b),(b,a)):
                row.setdefault('overlaps',[]).append(other['id'])
    for r in results:
        if r.get('overlaps'): r['errors'].append('Возможное пересечение: '+', '.join(r['overlaps'])+'. Уточните контуры или исключите дубликат.')
        r['confirmed']=bool(byid[r['id']].get('confirmed')) and not r['errors']
    return results
