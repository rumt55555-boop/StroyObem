from pathlib import Path
p=Path('android/app/src/main/AndroidManifest.xml')
s=p.read_text()
if 'android.permission.INTERNET' not in s:s=s.replace('<application','<uses-permission android:name="android.permission.INTERNET"/>\n    <application',1)
s=s.replace('android:label="stroyobem"','android:label="СтройОбъём"')
if 'android:usesCleartextTraffic' not in s:s=s.replace('<application','<application android:usesCleartextTraffic="true"',1)
p.write_text(s)
# minSdk 24 required by WebView package.
p=Path('android/app/build.gradle.kts')
if p.exists():p.write_text(p.read_text().replace('minSdk = flutter.minSdkVersion','minSdk = 24'))
