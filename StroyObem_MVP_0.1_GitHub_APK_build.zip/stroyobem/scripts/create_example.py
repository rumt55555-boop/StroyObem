"""Creates a clearly labelled synthetic control drawing and project, not real data."""
import sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import fitz
from backend import service
out=Path(__file__).resolve().parents[1]/'examples'
out.mkdir(exist_ok=True)
doc=fitz.open()
for title in ['CONCRETE CONTROL - SYNTHETIC DRAWING','EXCAVATION CONTROL - SYNTHETIC DRAWING']:
    pg=doc.new_page(width=600,height=400);pg.insert_text((30,25),title,fontsize=12)
    pg.draw_line((30,350),(130,350));pg.insert_text((50,370),'10.000 m - calibration')
pg=doc[0];pg.draw_line((40,60),(140,60));pg.insert_text((40,45),'Wall: L=10 m, H=3 m, t=0.2 m, openings=2 m2')
pg.draw_rect(fitz.Rect(200,60,204,64));pg.insert_text((200,45),'Column: 0.4 x 0.4 x 3 m')
pg.draw_rect(fitz.Rect(40,150,140,230));pg.insert_text((40,140),'Slab: 10 x 8 m, t=0.2 m, openings=4 m2')
pg=doc[1];pg.draw_rect(fitz.Rect(40,60,140,140));pg.insert_text((40,45),'Pit: 10 x 8 m, depth=2 m, vertical sides')
raw=doc.tobytes();doc.close();(out/'control-drawing.pdf').write_bytes(raw)
_,p=service.dispatch('POST','/api/projects',json.dumps({'name':'Условный контрольный проект — не реальные чертежи'}).encode(),{})
url='/api/projects/'+p['id'];_,p=service.dispatch('POST',url+'/pdf',raw,{'x-filename':'control-drawing.pdf'})
for page in p['pages']:page['calibration']={'points':[[30,350],[130,350]],'meters':10,'verified':True}
def element(id,kind,points,height,openings=0,thickness=None,page=0):return {'id':id,'kind':kind,'page':p['pages'][page]['id'],'points':points,'height':height,'openings':openings,'thickness':thickness,'floor':'0.000','axes':'А-Б / 1-2','section':'КР','notes':'Условный контрольный пример','confirmed':False,'excluded':False}
p['elements']=[element('W1','wall',[[40,60],[140,60]],3,2,.2),element('C1','column',[[200,60],[204,60],[204,64],[200,64]],3),element('S1','slab',[[40,150],[140,150],[140,230],[40,230]],.2,4),element('P1','pit',[[40,60],[140,60],[140,140],[40,140]],2,page=1)]
_,p=service.dispatch('PUT',url,json.dumps(p).encode(),{})
for e in p['elements']:
    _,p=service.dispatch('POST',url+'/confirm',json.dumps({'id':e['id'],'revision':p['revision']}).encode(),{})
(out/'control-project.json').write_text(json.dumps(p,ensure_ascii=False,indent=2))
_,xlsx=service.dispatch('GET',url+'/final',b'',{});(out/'control-schedule.xlsx').write_bytes(xlsx)
print('Создан контрольный проект. Бетон: 5.6 + 0.48 + 15.2 = 21.28 м³. Грунт: 160 м³.')
