#!/usr/bin/env bash
# Build СтройОбъём's Flutter Android client from the current source tree.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT/android_client"
if ! command -v flutter >/dev/null 2>&1; then
  echo 'ERROR: Flutter SDK is required (Flutter 3.47.x recommended).' >&2
  exit 1
fi
flutter --version

# This MVP stores only handwritten Flutter code in the archive; the native
# Android scaffold is recreated deterministically from the selected SDK.
flutter create --platforms=android --org ru.stroyobem --project-name stroyobem .
mkdir -p assets/ui
cp "$ROOT/web/index.html" "$ROOT/web/app.js" "$ROOT/web/style.css" "$ROOT/web/sw.js" assets/ui/
python3 "$ROOT/scripts/configure_android.py"

# flutter create generates a boilerplate widget test for its default MyApp.
# It does not apply to the actual StroyApp and must not fail static analysis.
if [[ -f test/widget_test.dart ]] && grep -q 'MyApp' test/widget_test.dart; then
  rm test/widget_test.dart
fi

flutter pub get
flutter analyze --no-fatal-infos
flutter build apk --debug
APK="$PWD/build/app/outputs/flutter-apk/app-debug.apk"
if [[ ! -s "$APK" ]]; then
  echo "ERROR: Build produced no APK at $APK" >&2
  exit 1
fi
mkdir -p "$ROOT/dist"
cp "$APK" "$ROOT/dist/StroyObem-MVP-0.1-debug.apk"
echo "APK: $ROOT/dist/StroyObem-MVP-0.1-debug.apk"
