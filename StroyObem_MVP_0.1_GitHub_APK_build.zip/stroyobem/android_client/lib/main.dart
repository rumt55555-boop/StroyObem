import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:share_plus/share_plus.dart';
import 'package:cross_file/cross_file.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';

void main() { WidgetsFlutterBinding.ensureInitialized(); runApp(const StroyApp()); }
class StroyApp extends StatelessWidget {
  const StroyApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false, title:'СтройОбъём',
    theme:ThemeData(colorScheme:ColorScheme.fromSeed(seedColor:const Color(0xff175c46)),useMaterial3:true),
    home:const Workspace());
}
class Workspace extends StatefulWidget {
  const Workspace({super.key});
  @override State<Workspace> createState()=>_WorkspaceState();
}
class _WorkspaceState extends State<Workspace> {
  HttpServer? server;
  WebViewController? web;
  String upstream='http://10.0.2.2:8000';
  String? error;
  @override void initState(){super.initState();initialize();}
  Future<void> initialize() async {
    try {
      final prefs=await SharedPreferences.getInstance();
      upstream=prefs.getString('server')??upstream;
      // Stable loopback origin preserves IndexedDB across launches. UI is bundled.
      server=await HttpServer.bind(InternetAddress.loopbackIPv4,18743);
      server!.listen(serve);
      final controller=WebViewController();
      await controller.setJavaScriptMode(JavaScriptMode.unrestricted);
      await controller.setNavigationDelegate(NavigationDelegate(onNavigationRequest:(r){
        final u=Uri.parse(r.url);
        return u.host=='127.0.0.1'&&u.port==18743?NavigationDecision.navigate:NavigationDecision.prevent;
      }));
      await controller.addJavaScriptChannel('AndroidExport',onMessageReceived:(m) async {
        try {
          final data=jsonDecode(m.message) as Map<String,dynamic>;
          final name=data['name']=='project.json'?'project.json':'stroyobem.xlsx';
          final bytes=base64Decode(data['data'] as String);
          await SharePlus.instance.share(ShareParams(
            files:[XFile.fromData(bytes,mimeType:name.endsWith('.json')?'application/json':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')],
            fileNameOverrides:[name],title:'Сохранить ведомость'));
        }catch(e){message('Не удалось сохранить: $e');}
      });
      if(controller.platform is AndroidWebViewController){
        final android=controller.platform as AndroidWebViewController;
        await android.setOnShowFileSelector((params) async {
          final result=await FilePicker.platform.pickFiles(type:FileType.custom,allowedExtensions:['pdf'],allowMultiple:true);
          return result?.paths.whereType<String>().map((p)=>Uri.file(p).toString()).toList()??[];
        });
        await android.setOnJavaScriptTextInputDialog((r) async {
          if(!mounted)return '';
          final field=TextEditingController(text:r.defaultText);
          final result=await showDialog<String>(context:context,builder:(context)=>AlertDialog(title:Text(r.message),content:TextField(controller:field,autofocus:true),actions:[TextButton(onPressed:()=>Navigator.pop(context,''),child:const Text('Отмена')),FilledButton(onPressed:()=>Navigator.pop(context,field.text),child:const Text('Сохранить'))]));
          field.dispose();return result??'';
        });
        await android.setOnJavaScriptConfirmDialog((r) async {
          if(!mounted)return false;
          return await showDialog<bool>(context:context,builder:(context)=>AlertDialog(content:Text(r.message),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('Отмена')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Да'))]))??false;
        });
      }
      await controller.loadRequest(Uri.parse('http://127.0.0.1:18743/'));
      if(mounted)setState(()=>web=controller);
    }catch(e){if(mounted)setState(()=>error='$e');}
  }
  Future<void> serve(HttpRequest request) async {
    try {
      final path=request.uri.path;
      if(path.startsWith('/api/')){
        final client=HttpClient()..connectionTimeout=const Duration(seconds:10);
        try {
          final target=Uri.parse(upstream).resolve(path);
          final proxy=await client.openUrl(request.method,target);
          proxy.followRedirects=false;
          for(final key in ['content-type','x-filename']){
            final value=request.headers.value(key);if(value!=null)proxy.headers.set(key,value);
          }
          await proxy.addStream(request);
          final response=await proxy.close().timeout(const Duration(seconds:30));
          request.response.statusCode=response.statusCode;
          request.response.headers.contentType=response.headers.contentType;
          await request.response.addStream(response);
        } finally {client.close(force:true);}
      }else{
        const files={'/':'index.html','/app.js':'app.js','/style.css':'style.css','/sw.js':'sw.js'};
        final file=files[path];
        if(file==null){request.response.statusCode=404;}
        else {
          final asset=await rootBundle.load('assets/ui/$file');
          request.response.headers.set('Content-Type',file.endsWith('.js')?'application/javascript':file.endsWith('.css')?'text/css':'text/html; charset=utf-8');
          request.response.add(asset.buffer.asUint8List(asset.offsetInBytes,asset.lengthInBytes));
        }
      }
    }catch(e){
      request.response.statusCode=503;
      request.response.headers.contentType=ContentType.json;
      request.response.write(jsonEncode({'error':'Сервер недоступен. Локальные черновики сохранены.'}));
    }finally{await request.response.close();}
  }
  void message(String text){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(text)));}
  Future<void> settings() async {
    final text=TextEditingController(text:upstream);
    final value=await showDialog<String>(context:context,builder:(context)=>AlertDialog(title:const Text('Адрес вашего сервера'),content:Column(mainAxisSize:MainAxisSize.min,children:[const Text('Эмулятор: http://10.0.2.2:8000\nТелефон: адрес компьютера в доверенной локальной сети. Для удалённого доступа нужен защищённый сервер.'),TextField(controller:text)]),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Отмена')),FilledButton(onPressed:()=>Navigator.pop(context,text.text),child:const Text('Подключить'))]));
    text.dispose();if(value==null)return;
    final uri=Uri.tryParse(value.trim());
    if(uri==null||!['http','https'].contains(uri.scheme)||uri.host.isEmpty||uri.userInfo.isNotEmpty){message('Некорректный адрес');return;}
    upstream='${uri.scheme}://${uri.authority}';
    final prefs=await SharedPreferences.getInstance();await prefs.setString('server',upstream);
    message('Адрес сохранён. Нажмите «Синхронизировать» в данных проекта.');
  }
  @override void dispose(){server?.close(force:true);super.dispose();}
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('СтройОбъём'),actions:[IconButton(onPressed:settings,icon:const Icon(Icons.settings_outlined),tooltip:'Сервер')]),
    body:SafeArea(child:error!=null?Center(child:Text('Не удалось открыть приложение: $error')):web==null?const Center(child:CircularProgressIndicator()):WebViewWidget(controller:web!)));
}
