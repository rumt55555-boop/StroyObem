import copy,io,math,os,tempfile,unittest
os.environ['STROY_DATA']=tempfile.mkdtemp(prefix='stroyobem-tests-')
import fitz
from openpyxl import load_workbook
from backend.engine import calculate,evaluate,area
from backend.storage import Store,Conflict
from backend.export import workbook
from backend import service

def page(): return {'id':'page1','width':1000,'height':1000,'name':'test.pdf','number':1,'document':'test','calibration':{'verified':True,'points':[[0,0],[100,0]],'meters':10}}
def element(kind='wall',**kwargs):
    e={'id':'e1','page':'page1','kind':kind,'points':[[0,0],[100,0]],'height':3,'thickness':.2,'openings':2,'floor':'1','confirmed':False}
    if kind!='wall': e.update(points=[[0,0],[100,0],[100,80],[0,80]],openings=0)
    e.update(kwargs); return e

def project(elements=None): return {'id':'p1','name':'Контроль','revision':1,'pages':[page()],'elements':elements or [element()]}
class EngineTests(unittest.TestCase):
    def test_wall(self): self.assertAlmostEqual(calculate(element(),page())['value'],5.6)
    def test_column(self): self.assertAlmostEqual(calculate(element('column',points=[[0,0],[4,0],[4,4],[0,4]],height=3),page())['value'],.48)
    def test_slab(self): self.assertAlmostEqual(calculate(element('slab',height=.2,openings=4),page())['value'],15.2)
    def test_pit(self): self.assertAlmostEqual(calculate(element('pit',height=2),page())['value'],160)
    def test_concave(self): self.assertEqual(area([(0,0),(4,0),(4,1),(1,1),(1,4),(0,4)]),7)
    def test_scale_required(self):
        p=page();p['calibration']['verified']=False
        with self.assertRaises(ValueError): calculate(element(),p)
    def test_self_intersection(self):
        with self.assertRaises(ValueError): area([(0,0),(10,10),(0,10),(10,0)])
    def test_invalid_numbers(self):
        for v in [None,-1,0,float('nan'),float('inf'),True]:
            with self.subTest(v=v),self.assertRaises(ValueError): calculate(element(height=v),page())
    def test_openings(self):
        with self.assertRaises(ValueError): calculate(element(openings=31),page())
    def test_outside(self):
        with self.assertRaises(ValueError): calculate(element(points=[[0,0],[1200,0]]),page())
    def test_overlaps_block_final(self):
        p=project([element(confirmed=True),element(id='e2',confirmed=True)])
        self.assertTrue(all(r['errors'] for r in evaluate(p)))
        with self.assertRaises(ValueError): workbook(p,True)
    def test_excluded_duplicates(self):
        p=project([element(confirmed=True),element(id='e2',excluded=True)])
        self.assertEqual(len(evaluate(p)),1); self.assertTrue(evaluate(p)[0]['confirmed'])
    def test_separate_floors(self):
        self.assertTrue(all(not r['errors'] for r in evaluate(project([element(),element(id='e2',floor='2')]))))
    def test_unconfirmed_final_blocked(self):
        with self.assertRaises(ValueError): workbook(project(),True)
    def test_xlsx_formulas_and_no_injection(self):
        p=project([element(confirmed=True,notes='=HYPERLINK("x")')]); wb=load_workbook(io.BytesIO(workbook(p,True)))
        self.assertEqual(wb.sheetnames,['Общие работы','Монолитные работы','Земляные работы','Настройки проекта'])
        ws=wb['Монолитные работы'];self.assertEqual(ws['L2'].value,'=(S2*T2-W2)*U2');self.assertEqual(ws['R2'].data_type,'s')
        self.assertEqual(ws['S2'].value,10);self.assertEqual(ws['T2'].value,3)
    def test_revision_conflict(self):
        s=Store(tempfile.mktemp());p=project();s.save(p,0)
        with self.assertRaises(Conflict):s.save(p,0)
        self.assertEqual(len(s.history(p['id'])),1)
class APITests(unittest.TestCase):
    def setUp(self):
        _,self.p=service.dispatch('POST','/api/projects',b'{"name":"Test"}',{})
        doc=fitz.open();pg=doc.new_page(width=600,height=400);pg.draw_rect(fitz.Rect(50,50,150,130));raw=doc.tobytes();doc.close()
        _,self.p=service.dispatch('POST',self.url('/pdf'),raw,{'x-filename':'control.pdf'})
    def url(self,s=''):return '/api/projects/'+self.p['id']+s
    def save_element(self):
        pg=self.p['pages'][0]; pg['calibration']=page()['calibration'];e=element(page=pg['id']);self.p['elements']=[e]
        _,self.p=service.dispatch('PUT',self.url(),__import__('json').dumps(self.p).encode(),{})
    def test_pdf_render(self):
        status,data=service.dispatch('GET',self.url('/page/'+self.p['pages'][0]['id']),b'',{})
        self.assertEqual(status,200);self.assertTrue(data['image'].startswith('data:image/png;base64,'))
    def test_confirmation_reset_and_history(self):
        import json
        self.save_element();_,self.p=service.dispatch('POST',self.url('/confirm'),json.dumps({'id':'e1','revision':self.p['revision']}).encode(),{})
        self.assertTrue(self.p['elements'][0]['confirmed']);self.p['elements'][0]['height']=4
        _,self.p=service.dispatch('PUT',self.url(),json.dumps(self.p).encode(),{})
        self.assertFalse(self.p['elements'][0]['confirmed']);self.assertEqual(len(service.store.history(self.p['id'])),5)
    def test_client_cannot_confirm(self):
        import json
        self.save_element(); self.p['elements'][0]['confirmed']=True
        _,self.p=service.dispatch('PUT',self.url(),json.dumps(self.p).encode(),{})
        self.assertFalse(self.p['elements'][0]['confirmed'])
    def test_calibration_resets_confirmation(self):
        import json
        self.save_element();_,self.p=service.dispatch('POST',self.url('/confirm'),json.dumps({'id':'e1','revision':self.p['revision']}).encode(),{})
        self.p['pages'][0]['calibration']['meters']=20
        _,self.p=service.dispatch('PUT',self.url(),json.dumps(self.p).encode(),{})
        self.assertFalse(self.p['elements'][0]['confirmed'])
    def test_invalid_pdf(self):
        with self.assertRaises(ValueError): service.dispatch('POST',self.url('/pdf'),b'not pdf',{})
    def test_full_flow(self):
        import json
        self.save_element();_,rows=service.dispatch('GET',self.url('/calculate'),b'',{});self.assertAlmostEqual(rows[0]['value'],5.6)
        service.dispatch('POST',self.url('/confirm'),json.dumps({'id':'e1','revision':self.p['revision']}).encode(),{})
        _,data=service.dispatch('GET',self.url('/final'),b'',{});self.assertTrue(data.startswith(b'PK'))
if __name__=='__main__':unittest.main()
